import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { CustomRoutingModule } from './custom-routing.module';
import { BadgeModule, CardModule, GridModule } from '@coreui/angular';

import { SubCustomComponent } from './sub-custom/sub-custom.component';
import { ChartjsModule } from '@coreui/angular-chartjs';
import { DocsComponentsModule } from '@docs-components/docs-components.module';


@NgModule({
  declarations: [SubCustomComponent],
  imports: [
    CommonModule,
    CustomRoutingModule,
    ChartjsModule,
    CardModule,
    GridModule,
    BadgeModule,
    DocsComponentsModule
  ]
})
export class CustomModule { }
