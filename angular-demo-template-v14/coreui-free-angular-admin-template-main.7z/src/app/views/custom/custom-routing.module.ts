import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';

import { SubCustomComponent } from './../custom/sub-custom/sub-custom.component';

const routes: Routes = [
  {
    path: '',
    component: SubCustomComponent,
    data: {
      title: 'SubCustom',
    },
  },
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class CustomRoutingModule { }
